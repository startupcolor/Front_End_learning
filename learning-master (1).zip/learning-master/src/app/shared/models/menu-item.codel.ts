export interface MenuItem {
  path: string;
  title: string;
}
